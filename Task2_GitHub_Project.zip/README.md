# Task 2 - Data Analytics Project

## Overview
Advanced data analysis using SQL, KPIs, and dashboard.

## Files
- queries.sql
- Superstore_Cleaned.xlsx
- Task2_Report.pdf

## Tools
Excel, SQL, Power BI
