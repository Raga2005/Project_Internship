-- Task 2 SQL Queries

SELECT Region, Segment, SUM(Sales) AS Total_Sales
FROM superstore
GROUP BY Region, Segment;

SELECT Category, SUM(Profit) AS Total_Profit
FROM superstore
GROUP BY Category;

SELECT Customer_Name, SUM(Sales) AS Total_Sales
FROM superstore
GROUP BY Customer_Name
ORDER BY Total_Sales DESC
LIMIT 10;

SELECT SUM(Sales)/COUNT(DISTINCT Order_ID) AS AOV
FROM superstore;
